document.querySelectorAll('input').forEach((input) => {
  input.addEventListener('input', () => input.classList.toggle('has-value', input.value.length > 0));
});
